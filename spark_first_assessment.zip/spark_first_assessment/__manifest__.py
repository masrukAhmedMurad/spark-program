# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Spark Assessment',
    'version': '1.0.0',
    'author': "M. A. Murad",
    'summary': 'Spark Assessment demo......',
    'sequence': -100,
    'description': """This is A demo module creation""",
    'category': 'Education',
    'depends': [],
    'data': [
        'security/ir.model.access.csv',
        'views/spark_assessment_views.xml',
        'views/menus.xml',

    ],
    'demo': ['base'],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
